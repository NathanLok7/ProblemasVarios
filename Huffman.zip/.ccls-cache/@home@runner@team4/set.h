#ifndef SET_H_
#define SET_H_

typedef int boolean;
#define TRUE 1
#define FALSE 0

/* Function pointer para la funcion de comparacion, esta la programa
el usuario para poder utilizar el arbol. El usuario es responsable de 
determinar si un objeto a guardar en el arbol es mas grande que el otro.

Esta funcion tambien podria ser definida asi:
typedef int  (*comp_func)(void *, void *);
Es opcionar poner el nombre de la variable en los prototipos de funcion
Por esta vez usamos A y B para poder ejemplificar lo siguiente:

Si ambos objetos son iguales = regresa 0
Si el objeto A < B           = regresa -1
Si el objeto A > B           = regresa 1 */
typedef int  (*comp_func)(void * A, void * B);

/* function pointer a una funcion para imprimir el dato.
El arbol no sabe que guarda, (son solo void *) asi que necesita
saber como interpretar e imprimir el dato. Esta funcion provista
por el usuario nos ayuda con esta tarea */
typedef void (*print_func)  (void *);

/* Nuestro Set */
typedef struct set_str set;

/* Funciones publicas del TDA Set */
set * set_create(comp_func, print_func);
int  set_size(set *);
boolean set_add(set *, void *);
boolean set_contains(set *, void *);
void set_print(set *);
boolean set_remove(set *, void *);
void set_destroy(set *);

#endif /* SET_H_ */
