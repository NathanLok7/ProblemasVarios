#include "map.h"
#include "pq.h"
#include "set.h"
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

//Compilar: gcc main.c pq.c map.c set.c -o main.exe

typedef struct node_str {
  char letra;
  int frecuencia;
  struct node_str *left, *right;
} node;

typedef struct mapa {
  int size;
  int capacity;
  struct node_str **array;
} mapa;

void print_frequency(char *string, pq *pq1,node* arr);

void createHuffmanTree(node *arr,int length);

int compareInts(void *t1, void *t2) {

  node *comp1 = (node *)t1;
  node *comp2 = (node *)t2;
  int i1 = comp1->frecuencia;
  int i2 = comp2->frecuencia;
  return i1 - i2;
}

int compareDir(void *t1, void *t2) {

  node *comp1 = (node *)&t1;
  node *comp2 = (node *)&t2;
  int * i1 = &comp1;
  int  *i2 = &comp2;
  return i1 - i2;
}

void printInt(void * t) {
	int* i = (int*) t;
	printf("%2d", *i);
}

int main(void) {
  char string[] = "The sun is a huge ball of gases.  It has a hugediameter. It "
                  "is so huge that it can hold millions of planets inside it. "
                  "The Sun is mainly made up of hydrogen and helium gas.";
  int length = strlen(string);
  pq *pq1 = pq_create(length, compareInts);
  node arr[length] ;
  print_frequency(string, pq1,arr);
  
  
  //printf("test: %d\n", arr[21].frecuencia);
  createHuffmanTree(arr,24);
  // juan pedro, nathan, lgarcia
}

/*
int pq_size(pq * queue)
{
        return queue->size;
}
*/

// createLeaf function (newNode)

void print_frequency(char *string, pq *pq1,node * arr) {
  int length = strlen(string);
  printf("\n");
  printf("LONGITUD DE LA STRING: %d\n\n", length);

  char unique[length];
  int counted = 0;

  printf("//////////////////////////////////////\n");
  printf("FRECUENCIA DE CARACTERES EN LA STRING\n");
  printf("/////////////////////////////////////\n");

  for (int i = 0; i < length; i++) {
    bool already_counted = false;
    for (int j = 0; j < counted; j++)
      if (string[i] == unique[j])
        already_counted = true;

    if (already_counted)
      continue;

    int count = 0;
    for (int j = 0; j < length; j++) {
      if (string[i] == string[j])
        count++;
    }

    printf("%c - %d\n", string[i], count);
    unique[counted] = string[i];
    counted++;

    node *n1 = malloc(sizeof(struct node_str));
    n1->frecuencia = count;
    n1->left = NULL;
    n1->right = NULL;
    n1->letra = string[i];
    
    pq_offer(pq1, n1);
  }
  printf("\n");
  printf("///////////////////////////////////////////////\n");
  printf("FRECUENCIA ORDENADA DE CARACTERES EN LA STRING\n");
  printf("//////////////////////////////////////////////\n");
  int x=0;
  while (pq_size(pq1) > 0) {
    node *menor = (node *)pq_peek(pq1);
    printf("%c - %d\n", menor->letra, menor->frecuencia);
    arr[x] = *menor;
    pq_poll(pq1);
    x++;
  }
   printf("\n");

}


void createHuffmanTree(node * arr,int length) {
set *list = set_create(compareDir, printInt);

  printf("/////////////////\n");
  printf("MAPA DE HUFFMAN\n");
  printf("////////////////\n");
  
  int i = 0;
  int aux[length];
  char c[length];
  node nodes[length];
  node * direcciones[length];
  printf("length is :%i\n", length);
  for (int z = 0; z < 24; z++) { // this works
    nodes[z].frecuencia = arr[z].frecuencia;
    nodes[z].letra =arr[z].letra;
    direcciones[z] = &nodes[z];
    }
   
  while (i != 24) {
    
      printf("I HATE DEBUGGING FREQ: %d LETR: %d DIR: %p\n",nodes[i].frecuencia,nodes[i].letra,direcciones[i]);
      printf("arr %i es: %d con la letra %c \n",i,arr[i].frecuencia,arr[i].letra);
     // printf("aux es : %d \n",aux);

    set_add(list, &direcciones[i]);
    set_print(list);
    i++;
  }
  
  printf("lista final\n");
  set_print(list);
}

void swap_node(struct mapa **a, struct mapa **b) {
  void *node = *a;
  *a = *b;
  *b = node;
}
/*
void printText(int arrbin[], int a)
{
  while(arrbin[] != NULL)
  {
    for(int i = 0; i < a; i++){
      printf("%d", arrbin[i]);
    }
  }
  return;
}

*/

//char *temp = a;
char t[100];

void code_tree(struct node_str *a, struct mapa *b, char *string, pq * pq1) {
  int i = 0;
  static char *temp = t;
  char *polo[256];
  string[i] = 0;

  if (a == NULL)
    printf("NULL");
    return;
  
  while (b->size > 0) {
    polo[a->letra] = temp;
    //temp += pq_size(pq1) + 1;
    temp += b->size + 1;
    return;
    b->size--;
  }
  code_tree(a->right, b, string, pq1);
  code_tree(a->left, b, string, pq1);
  return;
}

void print_binary(struct node_str *a, char * string)
{
  string = malloc(strlen(string) +1);
  string = NULL;
  
  while(string != NULL){
      
  }
  return;
}

// Convertir texto original en nuevo texto comprimido en binario (imprimirlo).

void decode_func(struct node_str *a, char *string, struct mapa *b) {
  int t = 0;
  string = NULL;
  struct node_str *temp = a;

  for (int i = 0; i < b->size; i++) {
    if (string[i] == '0')
      temp = temp->left;
    else
      temp = temp->right;

    if (temp->left == NULL || temp->right == NULL)
      printf("End");
    temp = a;
    return;
  }
}
