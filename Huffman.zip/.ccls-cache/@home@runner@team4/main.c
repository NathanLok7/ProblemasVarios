#include "map.h"
#include "pq.h"
#include "set.h"
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

//Compilar: gcc main.c pq.c map.c set.c -o main.exe

typedef struct node_str {
  char letra;
  int frecuencia;
  struct node_str *left, *right;
} node;

typedef struct mapa {
  int size;
  int capacity;
  struct node_str **array;
} mapa;

typedef struct heap{
 node *left;
 node *right;
 node head;
} heap;

char t[128];
char *temp[128];
int binary;

//int print_frequency(char *string, pq *pq1,node* arr);

node createHuffmanTree(pq * pq1);
void printBinary(node *pray, int binary);
void dictionary(node *a,map * new_map,int flag,int bins[]);

int compareInts(void *t1, void *t2) {

  node *comp1 = (node *)t1;
  node *comp2 = (node *)t2;
  int i1 = comp1->frecuencia;
  int i2 = comp2->frecuencia;
  return i1 - i2;
}

int compareDir(void *t1, void *t2) {

  node *comp1 = (node *)&t1;
  node *comp2 = (node *)&t2;
  return comp1 - comp2;
}

int hashFunc(char* a){
  int *aux = (int*)a ;
  aux = aux +10;
  return(*aux);
}

int wordHash(void *t) { //copiado del demo de map
	char *key = (char *)t;
	int i, hash = 0;
	for (i = 0; i < strlen(key); i++) {
		hash += (key[i] - 'a');
	}
	//printf("wordHash(): key %s, hash %d\n", key, hash);
	return hash;
}

void printInt(void * t) {
	int* i = (int*) t;
	printf("%2d", *i);
}

void printPoint(void * t){
  node * i = (node*)t;
  printf("%p\n",i);
}

int main(void) {
  char string[] = "The sun is a huge ball of gases.  It has a hugediameter. It "
                  "is so huge that it can hold millions of planets inside it. "
                  "The Sun is mainly made up of hydrogen and helium gas.";
  int length = strlen(string);
  pq *pq1 = pq_create(length, compareInts);
  pq *pq2 = pq_create(length, compareInts);

  node arr[length] ;
  printf("\n");
  printf("LONGITUD DE LA STRING: %d\n\n", length);
  char unique[length];
  int counted = 0;
  printf("//////////////////////////////////////\n");
  printf("FRECUENCIA DE CARACTERES EN LA STRING\n");
  printf("/////////////////////////////////////\n");
  for (int i = 0; i < length; i++) {
    bool already_counted = false;
    for (int j = 0; j < counted; j++)
      if (string[i] == unique[j])
        already_counted = true;

    if (already_counted)
      continue;

    int count = 0;
    for (int j = 0; j < length; j++) {
      if (string[i] == string[j])
        count++;
    }

    printf("%c - %d\n", string[i], count);
    unique[counted] = string[i];
    counted++;

    node *n1 = malloc(sizeof(struct node_str));
    n1->frecuencia = count;
    n1->left = NULL;
    n1->right = NULL;
    n1->letra = string[i];
    
    pq_offer(pq1, n1);
    pq_offer(pq2, n1);
  }
  printf("\n");
  printf("///////////////////////////////////////////////\n");
  printf("FRECUENCIA ORDENADA DE CARACTERES EN LA STRING\n");
  printf("//////////////////////////////////////////////\n");
  int x=0;
  while (pq_size(pq1) > 0) {
    node *menor = (node *)pq_peek(pq1);
    node *menor2 = (node *)pq_peek(pq2);

    printf("%c - %d\n", menor->letra, menor->frecuencia);
    pq_poll(pq1);
    x++;
  }
  printf("\n");
  printf("Total de caracteres unicos: %i \n",counted);
    
  //coded_tree(0, 0, string, pq1);
  //printText(array, a); //No
  
  //printf("test: %d\n", arr[21].frecuencia);
  
  printf("\n/////////////////\n");
  printf("ARBOL DE HUFFMAN\n");
  printf("////////////////\n\n");
  
  node * start= (node*)malloc(sizeof(struct node_str));
  //map * print_map = print_binary(start, binary);
  //map * prueba = prueba(pray);
  
  //compress huffman
  while(pq_size(pq2) > 0){
    printf("PQ SIZE ES: %d\n",pq_size(pq2));
    int x = pq_size(pq2);
    //printf("SI ENTRA\n");
    if(pq_size(pq2) == 1){
      start = pq_poll(pq2);
      break;
    }
    node * aux1 = (node*)pq_poll(pq2);
    node * aux2 = (node*)pq_poll(pq2);
    node * head = (node*)malloc(sizeof(struct node_str));
    int head_value = aux1->frecuencia + aux2->frecuencia;
    head->frecuencia = head_value;
    head->left = aux1;
    head->right = aux2;
    printf("\nCaracteres: %d",head->frecuencia);
    printf("\nLetra %c se une con %c",head->left->letra,head->right->letra);
    
    pq_offer(pq2,head);
    printf("\n");

  
  
  // juan pedro, nathan, lgarcia
 }
  int bin[counted] ;
  int flag = 0b0000;
  map * map1 = map_create(counted, wordHash,compareInts);
  
  //Mando el flag en binario y cuando entra le doy ++
  //Esta funcion corre pero a la hora de tratar de usar map1 da segmentation fault
  dictionary(start ,map1, flag, bin);
  
  //Imprime texto en binario
  //Como no pudimos generar el mapa nos da un
  //printBinary(start, binary);
  //coded_tree
}

map * prueba(node * pray)
{
  printf("-----------------Test--------------------");
  void printBinary(node *pray, int binary);
}


void swap_node(struct mapa **a, struct mapa **b) {
  void *node = *a;
  *a = *b;
  *b = node;
}
/*
void printText(int arrbin[], int a)
{
  while(arrbin[] != NULL)
  {
    for(int i = 0; i < a; i++){
      printf("%d", arrbin[i]);
    }
  }
  return;
*/

//Function without values
void printText()
{
  //printf("Texto");
  printf("\n\n");
  for(int i = 0; i < binary; i++){
     printf("%c", t[i]);
  }
  printf("\n");
  return;
}

void dictionary(node *a, map * new_map, int  flag, int bins[])
{
  if(a->left == NULL || a->right == NULL)
   printf("NULL");
   map_put(new_map,&a->letra,&flag);
   flag++;
    return;
  dictionary(a->left,new_map,flag,bins);
  dictionary(a->right,new_map,flag,bins);
}

void printBinary(struct node_str * pray, int i)
{
  //printf("\nStart: \n");
  printf("%i", pray->frecuencia);
  if(pray == NULL)
  {
    printf("ERROR");
    return;
  }
  printf("\n");
  binary++;
  if(i == 0) {
    t[binary] = '0';
  }
  else if(i == 1) {
    t[binary] = '1';
  }
  
  printf("%d", binary);
  printf("%c", binary);
  printText();

  printBinary(pray->left, 0); binary--;
  printBinary(pray->right, 1); binary--;
}

//Generar hash único por letra
/*
int hash_letter(struct node_str * a, int i)
{
  node * hash_node = (node*)malloc((sizeof(node*));
  //hash_node = i;
  return hash_node->letra;
}
*/
// Convertir texto original en nuevo texto comprimido en binario (imprimirlo).
// Falta mapeo finalizado para su correcto funcionamiento
void decode_func(struct node_str *a, char *string, struct mapa *b) {
  int t = 0;
  string = NULL;
  struct node_str *temp = a;

  for (int i = 0; i < b->size; i++) {
    if (string[i] == '0')
      temp = temp->left;
    else
      temp = temp->right;

    if (temp->left == NULL || temp->right == NULL)
    {
      printf("End");
    }
    temp = a;
    return;
    }
}
