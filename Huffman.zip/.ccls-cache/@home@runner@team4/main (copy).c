#include "map.h"
#include "pq.h"
#include "set.h"
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

//Compilar: gcc main.c pq.c map.c set.c -o main.exe

typedef struct node_str {
  char letra;
  int frecuencia;
  struct node_str *left, *right;
} node;

typedef struct mapa {
  int size;
  int capacity;
  struct node_str **array;
} mapa;

typedef struct heap{
 node *left;
 node *right;
 node head;
} heap;

char t[128];
char *temp[128];
int binary = 0;

//int print_frequency(char *string, pq *pq1,node* arr);

node createHuffmanTree(pq * pq1);

int compareInts(void *t1, void *t2) {

  node *comp1 = (node *)t1;
  node *comp2 = (node *)t2;
  int i1 = comp1->frecuencia;
  int i2 = comp2->frecuencia;
  return i1 - i2;
}

int compareDir(void *t1, void *t2) {

  node *comp1 = (node *)&t1;
  node *comp2 = (node *)&t2;
  return comp1 - comp2;
}

void printInt(void * t) {
	int* i = (int*) t;
	printf("%2d", *i);
}

void printPoint(void * t){
  node * i = (node*)t;
  printf("%p\n",i);
}

int main(void) {
  char string[] = "The sun is a huge ball of gases.  It has a hugediameter. It "
                  "is so huge that it can hold millions of planets inside it. "
                  "The Sun is mainly made up of hydrogen and helium gas.";
  int length = strlen(string);
  pq *pq1 = pq_create(length, compareInts);
  pq *pq2 = pq_create(length, compareInts);

  node arr[length] ;
  printf("\n");
  printf("LONGITUD DE LA STRING: %d\n\n", length);
  char unique[length];
  int counted = 0;
  printf("//////////////////////////////////////\n");
  printf("FRECUENCIA DE CARACTERES EN LA STRING\n");
  printf("/////////////////////////////////////\n");
  for (int i = 0; i < length; i++) {
    bool already_counted = false;
    for (int j = 0; j < counted; j++)
      if (string[i] == unique[j])
        already_counted = true;

    if (already_counted)
      continue;

    int count = 0;
    for (int j = 0; j < length; j++) {
      if (string[i] == string[j])
        count++;
    }

    printf("%c - %d\n", string[i], count);
    unique[counted] = string[i];
    counted++;

    node *n1 = malloc(sizeof(struct node_str));
    n1->frecuencia = count;
    n1->left = NULL;
    n1->right = NULL;
    n1->letra = string[i];
    
    pq_offer(pq1, n1);
    pq_offer(pq2, n1);

  }
  printf("\n");
  printf("///////////////////////////////////////////////\n");
  printf("FRECUENCIA ORDENADA DE CARACTERES EN LA STRING\n");
  printf("//////////////////////////////////////////////\n");
  int x=0;
  while (pq_size(pq1) > 0) {
    node *menor = (node *)pq_peek(pq1);
    node *menor2 = (node *)pq_peek(pq2);

    printf("%c - %d\n", menor->letra, menor->frecuencia);
    pq_poll(pq1);
    x++;
  }
   printf("\n");
  printf("Total de caracteres unicos: %i \n",counted);
    
  //coded_tree(0, 0, string, pq1);
  //printText(array, a); //No
  
  //printf("test: %d\n", arr[21].frecuencia);
  
  printf("\n/////////////////\n");
  printf("ARBOL DE HUFFMAN\n");
  printf("////////////////\n\n");
  
  node * start= (node*)malloc(sizeof(struct node_str));
  //map * print_map = print_binary(start, binary);
  
  //compress huffman
  while(pq_size(pq2) > 0){
    printf("\nMI PQ SIZE ES: %d\n",pq_size(pq2));
    int x = pq_size(pq2);
    //printf("SI ENTRA\n");
    if(pq_size(pq2) == 1){
      start = pq_poll(pq2);
       
      break;
    }
    node * aux1 = (node*)pq_poll(pq2);
    node * aux2 = (node*)pq_poll(pq2);
    node * head = (node*)malloc(sizeof(struct node_str));
    int head_value = aux1->frecuencia + aux2->frecuencia;
    head->frecuencia = head_value;
    head->left = aux1;
    head->right = aux2;
    printf("\nCaracteres: %d",head->frecuencia);
    printf("\nLetra %c se une con %c",head->left->letra,head->right->letra);

      pq_offer(pq2,head);
   
    
  
   
  
  // juan pedro, nathan, lgarcia
 }
  
}

map * prueba(node * pray)
{
  printBinary(pray, binary);
}


void swap_node(struct mapa **a, struct mapa **b) {
  void *node = *a;
  *a = *b;
  *b = node;
}
/*
void printText(int arrbin[], int a)
{
  while(arrbin[] != NULL)
  {
    for(int i = 0; i < a; i++){
      printf("%d", arrbin[i]);
    }
  }
  return;
*/
//Function without values
void printText()
{
  for(int i = 0; i < binary; i++){
      printf("%c", t[i]);
  }
  return;
}

void dictionary(struct node_str *a, map * new_map)
{
  if(a->left == NULL || a->right == NULL)
    printf("NULL");
    return;

  char * the_string = (char*)malloc(128);
  //the_string = strcpy(the_string)
  
}



void coded_tree(struct node_str *a, char *string, pq * pq1) {
  int i;
  static char *temp = t;
  char *polo[256];
  string[i] = 0;

  if (a == NULL)
    printf("NULL");
    return;
  
  while (pq_size(pq1) > 0) {
    polo[a->letra] = temp;
    temp += pq_size(pq1) + 1;
    return;
  }
  coded_tree(a->right, string, pq1);
  coded_tree(a->left, string, pq1);
  return;
}

void printBinary(struct node_str * a, int i)
{
  if(a == NULL || i < 0)
    printf("ERROR");
    return;

  if(i <= 0)
    t[binary] = '0';
  else 
    t[binary] = '1';

  if(a == NULL)
    printf("%c", binary);
    printText();
}

// Convertir texto original en nuevo texto comprimido en binario (imprimirlo).

void decode_func(struct node_str *a, char *string, struct mapa *b) {
  int t = 0;
  string = NULL;
  struct node_str *temp = a;

  for (int i = 0; i < b->size; i++) {
    if (string[i] == '0')
      temp = temp->left;
    else
      temp = temp->right;

    if (temp->left == NULL || temp->right == NULL)
    {
      printf("End");
    }
    temp = a;
    return;
    }
}
