#include <stdlib.h>
#include <stdio.h>
#include "set.h"

/* Set
Un Set o Conjunto es un contenedor que nos permite guardar elementos
cumpliendo la siguiente propiedad:
   
  -Los elementos NUNCA se repiten, siempre son unicos.

Para poder garantizar que el elemento no existe, tenemos que revisar
todos los elementos previamente insertados. Utilizar una lista ligada
seria muy costoso ya que no podemos evitar recorrer todos y cada uno 
de los elementos.

Para facilitar esta tarea, nos apoyaremos de una clasica estructura de 
datos llamada "Arbol Binario de Busqueda" o BST en ingles (Binary
search tree). Esta estructura tiene la propiedad de que nos ayuda
a reducir el espacio de busqueda de un elemento ya solo se recorren
las ramas que sabemos que nos llevan a encontrarlo. 

Mas teoria y diagramas en la presentacion de clase
*/

/* Nodo, un BST esta hecho de nodos, y cada uno debe tener 2 apuntadores,
uno para la hoja izquierda y otro la derecha
Como todos los demas TDAs que hemos visto en clase, guarda un typo Type
que es un void * para permitir guardar "cualquier cosa" */
struct node_str 
{
	void * data;
	struct node_str *left, *right;
};

typedef struct node_str node;

/* Nuestro set, contiene un apuntador a la raiz del arbol, osea su punto unico
de entrada, asi como el tamanio del arbol y 2 apuntadores a funcion:
  -compare, que usaremos para determinar el orden de los elementos
  -print, que usaremos para interpretar e imprimir el contenido del nodo */
struct set_str 
{
	node * root;
	int size;
	comp_func compare;
	print_func   print;
};

/* Crea un set e inicializa a valores */
set * set_create(comp_func cf, print_func pf) 
{
	set * s1 = (set *) malloc(sizeof(struct set_str));
	s1->root = NULL;
	s1->size = 0;
	s1->compare = cf;
	s1->print   = pf;
	return s1;
}

/* retorna el tamanio del set (cuantos elementos unicos tiene) */

int set_size(set * s) 
{
	return s->size;
}

/* funcion para alocar y crear una hoja (nodo) nuevo del arbol */
node * createLeaf(void * data) {
	node * leaf   = (node *) malloc(sizeof(struct node_str));
	leaf->data   = data;
	leaf->left  = NULL;
	leaf->right = NULL;
	return leaf;
}

/* funcion para agregar (insertar) al arbol la hoja recien creada,
esta es la principal funcion que contiene la logica para construir el
arbol siguiend las reglas:
  - Si el elemento es mas chico -> se convierte* en hijo izquierdo
  - Si el elemento es mas grande -> se convierte* en hijo derecho.
  - Si el elemento es igual, no se inserta, ya que ya existe.

*solo se convierte en hijos izquierdos o derechos, si existe un 
apuntador libre, sino, tenemos que repetir la operacion en ese nodo
del arbol. 
NOTA : ESTA FUNCION ES RECURSIVA (pero tambien puede programarse de 
forma iterativa) */
boolean add_node(node * n, void * data, comp_func compare) 
{ 
	int res = compare(data, n->data);
	if(res == 0) 
		return FALSE;
  else if(res < 0) 
  {
		if(n->left == NULL) 
    {
      /* encontramos el final de esta rama, con espacio para insertar */
			n->left = createLeaf(data);
			return TRUE;
		} 
    else 
    {
			return add_node(n->left, data, compare);
		}
	} 
  else 
  {
		if(n->right == NULL) 
    {
      /* encontramos el final de esta rama, con espacio para insertar */
			n->right = createLeaf(data);
			return TRUE;
		} 
    else 
    {
			return add_node(n->right, data, compare);
		}
	}
}

/* Punto de entrada para agregar un elemento al set.
Recuerda que como esto es un TDA, podriamos mantener multiples Sets en
memoria la mismo tiempo, si solo estuvieramos construyendo un arbol Binario
de un tipo de dato conocido, podriamos ir directo a insertar a la raiz */
boolean set_add(set * s, void * data) 
{
  /* si la raiz es NULL o si no hay ningun elemento sabemos que el SET esta
  vacio, y podemos comenzar a crear el arbol, insertando el primer
  elemento como la raiz */
	if(s->root == NULL) 
  {
		s->root = createLeaf(data);
		s->size = 1;
		return TRUE;
	}
  /* si la raiz esta ocupada, comenzamos a buscar el lugar donde el nuevo
  nodo (hoja) va a existir. AQUI COMIENZA NUESTRA RECURSION 
  
  sabemos que add_node, lograra insertar el nuevo elemento al arbol
  o nos regresara FALSE si por el contrario ya existia, de una u otra forma
  sabremos el resultado al terminar esta funcion */
	if(add_node(s->root, data, s->compare) == TRUE)
  {
    s->size++;
    return TRUE;
  }
  return FALSE;
}

/* Funcion para agregar un nuevo elemento de forma iterativa (sin recursion) */
boolean set_add_iterative(set * s, void * data) 
{
	if(s->root == NULL) {		// if(set->size == 0) {
		s->root = createLeaf(data);
		s->size = 1;
		return TRUE;
	}
  //	El arbol no esta vacio. Hay que buscar el lugar para la clave nueva (key)
	boolean found = FALSE, added = FALSE;
	node * current = s->root;
	while(!found && !added) 
  {
		int res = s->compare(data, current->data);
		if(res == 0)      // key = current->key, EXISTS ALREADY ignore
    {				
			found = TRUE;
		} 
    else if(res < 0)  // key < current->key  ... take LEFT
    {		
			if(current->left == NULL) 
      {
				current->left = createLeaf(data);
				added = TRUE;
			} else 
      {
				current = current->left;
			}
		} 
    else // key > current->key ... take RIGHT
    {  					
			if(current->right == NULL) 
      {
				current->right = createLeaf(data);
				added = TRUE;
			} else 
      {
				current = current->right;
			}
		}
	}
	if(added) s->size ++;
	return added;
}

/* In-Order Print 
  Imprime IZQUIERDA - NODO - DERECHA  
  hasta llegar a apuntadores Nulos hojas del arbol */
void printKey(node * n, print_func print) 
{
	if(n == NULL) 
    return;
  
	printKey(n->left,  print);
	print(n->data); printf("\n");
  printKey(n->right, print);
  
}

/* Punto de entrada para imprimir todos los contenidos de un SET
Esta funcion hara un recorrido de arbol "In Order" 
https://dev.to/javinpaul/how-to-implement-inorder-traversal-in-a-binary-search-tree-1787
*/
void set_print(set *s) 
{
	printKey(s->root, s->print);
	printf("-------------------\n");
}

/* Analiza si ya existe un elemento en el arbol.
Esta funcion sigue la misma logica de recorrer (imprimir)
solamente se le agrega el factor de revisar si el elemento
existe y se evita explorar las ramas donde sabemos que 
ya no se puede encontrar el elemento */
boolean containsKey(node * n, void * data, comp_func compare) 
{
  if(n == NULL) 
    return FALSE;

	int res = compare(data, n->data);
	if(res == 0) return TRUE;

	if(res  < 0) 
  {
    return containsKey(n->left, data, compare);
  }
	else
  { 
    return containsKey(n->right, data, compare);
  }
}

/* Punto de entrada para set_contains */
boolean set_contains(set * s, void * data) {
	return containsKey(s->root, data, s->compare);
}


/* Para destruir el SET tenemos que destruir el arbol por completo,
en esta caso lo realizamos recorriendo nodo por nodo POST-ORDEN y
vamos liberando la memoria de los nodos que ya visitamos. Siempre desde
las hojas, nunca desde nodos intermedios 
El algortimo de recorrido POST-ORDEN nos ayuda a recorrer de esta
forma el arbol :

https://www.geeksforgeeks.org/tree-traversals-inorder-preorder-and-postorder/

*/ 
void destroyNode(node * n, print_func print) 
{
	if(n == NULL) 
    return;
	
  destroyNode(n->left,  print);
	destroyNode(n->right, print);

	printf("Se eliminará el nodo con clave: ");
	print(n->data);
	printf("\n");
	free(n);
}

void set_destroy(set * s) 
{
	destroyNode(s->root, s->print);
}
