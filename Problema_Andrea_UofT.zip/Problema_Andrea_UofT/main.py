# University of Toronto problem (CS class)

from typing import List, TextIO
  
def count_evens_from_file(number_file: TextIO) -> List[int]:

    line = number_file.read().splitlines()
    InitialList = []
    Temporal = []
    FinalList = []
  
    for i in line:
      #Append to temporal
        Temporal.append(i)
        if i == 'END':
            InitialList.append(Temporal)
            Temporal = []
    
    for i in InitialList:
        count = 0
        for j in i:
            if j.isdigit():
                if int(j) %2 != 0:
                    count += 1
        #Append to the final list
        FinalList.append(count)
      
    return FinalList

open = open('text.txt')
print(count_evens_from_file(open))
